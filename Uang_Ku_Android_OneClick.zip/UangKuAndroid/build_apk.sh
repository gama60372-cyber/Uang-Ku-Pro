#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "=========================================="
echo "Uang Ku Pro+ - One Click APK Builder"
echo "=========================================="
if command -v ./gradlew >/dev/null 2>&1; then
  ./gradlew assembleDebug
elif command -v gradle >/dev/null 2>&1; then
  gradle assembleDebug
else
  echo "ERROR: Gradle tidak ditemukan."
  echo "Buka project ini sekali di Android Studio atau install Gradle."
  exit 1
fi
echo
echo "APK: $(pwd)/app/build/outputs/apk/debug/app-debug.apk"
