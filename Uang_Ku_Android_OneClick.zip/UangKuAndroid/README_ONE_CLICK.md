# Uang Ku Pro+ — One Click APK

Project ini memakai `Uang_Ku_ULTRA_FINAL_100x.html` sebagai aset aplikasi Android.

## Windows
1. Buka folder `UangKuAndroid`.
2. Klik dua kali `build_apk.bat`.
3. APK debug berada di:
   `app\build\outputs\apk\debug\app-debug.apk`

## Android Studio
Open folder `UangKuAndroid`, tunggu Gradle sync, lalu:
Build -> Build APK(s).

## Tanpa Android Studio
Project sudah memiliki GitHub Actions di `.github/workflows/build-apk.yml`.
Upload folder ini ke repository GitHub, lalu jalankan workflow `Build Uang Ku APK`.
Artifact APK akan tersedia setelah workflow selesai.

Catatan: lingkungan ChatGPT saat ini tidak memiliki Android SDK/Gradle build tools, jadi saya tidak mengklaim telah menghasilkan APK binary yang belum benar-benar dibuild.
