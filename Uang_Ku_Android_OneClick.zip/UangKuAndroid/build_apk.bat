@echo off
setlocal
cd /d "%~dp0"
echo ==========================================
echo Uang Ku Pro+ - One Click APK Builder
echo ==========================================
where java >nul 2>&1 || (echo [ERROR] Java/JDK tidak ditemukan.&echo Install Android Studio/JDK lalu jalankan lagi.&pause&exit /b 1)
if exist "%~dp0gradlew.bat" (
  call "%~dp0gradlew.bat" assembleDebug
  if errorlevel 1 goto fail
) else (
  where gradle >nul 2>&1 || (echo [ERROR] Gradle tidak ditemukan.&echo Buka project ini sekali di Android Studio agar Gradle tersedia, atau install Gradle.&pause&exit /b 1)
  gradle assembleDebug
  if errorlevel 1 goto fail
)
echo.
echo [BERHASIL] APK:
echo %~dp0app\build\outputs\apk\debug\app-debug.apk
pause
exit /b 0
:fail
echo.
echo [GAGAL] Build belum selesai. Lihat pesan di atas.
pause
exit /b 1
