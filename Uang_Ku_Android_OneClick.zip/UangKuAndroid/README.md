# Uang Ku Pro+ — Android package source

This project wraps `Uang_Ku_ULTRA_FINAL_100x.html` in a native Android WebView shell.

## Build APK

Open this folder in Android Studio, let Gradle sync, then choose:
`Build > Build App Bundle(s) / APK(s) > Build APK(s)`.

The generated APK will be under:
`app/build/outputs/apk/debug/app-debug.apk`

Requirements:
- Android Studio with Android SDK Platform 35
- JDK 17+ (JDK 21 is also supported by current Android Studio/AGP setups)

The HTML remains the app's local asset. INTERNET permission is included because the app can update market data when connectivity is available; cached data in the HTML remains usable when connectivity is poor/offline.
